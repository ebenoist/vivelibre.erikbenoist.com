<html lang="en"><head>
    <meta charset="utf-8">
    <title>Twitter Bootstrap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
		<link rel="profile" href="http://gmpg.org/xfn/11" />
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo get_bloginfo('template_url')?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo get_bloginfo('template_url')?>/css/bootstrap-responsive.css" rel="stylesheet">
    <link href="<?php echo get_bloginfo('template_url')?>/css/docs.css" rel="stylesheet">
    <link href="<?php echo get_bloginfo('template_url')?>/js/google-code-prettify/prettify.css" rel="stylesheet"> 
    <link href="<?php echo get_bloginfo('template_url')?>/style.css" rel="stylesheet">
    <title>BronwynMead</title>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


  </head>

  <body data-spy="scroll" data-target=".subnav" data-offset="50" data-twttr-rendered="true">


    <div class="container">

<!-- Masthead
================================================== -->
<header class="jumbotron masthead">
  <div class="inner">
     <img src="<?php echo get_bloginfo('template_url') . '/images/new800pxbanner.png';?>">  

</div>

  <div class="bs-links">
    <ul class="quick-links">

<?php
  $pages = get_pages('exclude=16'); 
  foreach ( $pages as $page ) {
    $option = '<li><a href=' . get_page_link( $page->ID ) . "a>";
    $option .= $page->post_title;
    $option .= "</a></li>";
	  echo $option;
  }
 ?>
    </ul>
</header>

<hr class="soften">

<div class="marketing">
  
      
<?php 

if ( have_posts() ) {
  while ( have_posts() ) {
    the_post();
    get_template_part( '/partials/content', get_post_format() );
  }
}
else {
  get_template_part( '/partials/content', 'not-found' );
}
?>
</div><!-- /.marketing -->


    </div><!-- /container -->



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/application.js"></script>

    <!-- Analytics
    ================================================== -->
    <script>
      var _gauges = _gauges || [];
      (function() {
        var t   = document.createElement('script');
        t.type  = 'text/javascript';
        t.async = true;
        t.id    = 'gauges-tracker';
        t.setAttribute('data-site-id', '4f0dc9fef5a1f55508000013');
        t.src = '//secure.gaug.es/track.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(t, s);
      })();
    </script>

  

</body></html>
