var commData; 

var po = org.polymaps;

var labels = {};

var map = po.map()
    .container(document.getElementById("map").appendChild(po.svg("svg")))
	.center({lat: 15.5858, lon: -91.7373})
	.zoomRange([1, 17])
	.zoom(13)
	///.on("move", update_labels)
    //.on("resize", update_labels)
    .add(po.interact());
    

 
//map.add(po.layer(overlay)
 //   .tile(false));
    

	



 //map.add(po.geoJson()
  //  .url('jsonsources/municipios.json')
 //   .id("muni"));
       
       
 map.add(po.geoJson()
    .url('jsonsources/newcantinil.json')
    .id("cantinil"));
       

map.add(po.geoJson()
    .url('jsonsources/com.json')
    .on("load", load)

    .id("comunidades"));
       

    
map.add(po.geoJson()
    .url('jsonsources/newrios.json')
    .id("rios"));

map.add(po.geoJson()
    .url('jsonsources/newcentros.json')
    .on("load", add_labels)
    .id("centros"));
    
    
map.add(po.geoJson()
    .url('jsonsources/newcaminos.json')
    .id("caminos"));
    
//map.add(po.layer(overlay2)
  //  .tile(false));
 
 
map.add(po.compass().pan("none"));

    
function load(e) {
	commData = e;
  for (var i = 0; i < e.features.length; i++) {
    	var feature = e.features[i];
    
      var id = feature.id
      var name = feature.data.properties.NOMBRE;
      var codigo = feature.data.properties.COMCODIGO;
      var pob = feature.data.properties.POBLACION;
      var categoria = feature.data.properties.CATEGORIA;
      var hog = feature.data.properties.HOGARES;
      var alumnos = feature.data.properties.ALUMNOS;
      var elec	= feature.data.properties.ELECTRICIA;
      var tiendas = feature.data.properties.TIENDAS;
      var cantinas = feature.data.properties.CANTINAS;
      var fdata = feature;
      
      feature.element.appendChild(po.svg("text").appendChild(document.createTextNode(feature.data.properties.NOMBRE)).parentNode);
	  feature.element.setAttribute('onclick', 'set_footer("' + i + '");return false;');
	 // feature.element.onclick = function(fdata, event) { console.log(fdata); set_footer(fdata,event); };
	  //feature.element.setAttribute('onlick', 'set_footer(' + fdata + ')');
	  //feature.element.setAttribute('onmouseover', 'reportcords()');
	  //feature.element.setAttribute('onmouseout', 'clear_footer();return false;');	
	  
	  
	  
	 


   }
  } 
  
  
  function add_labels(e)
  {
  
    for (var i = 0; i < e.features.length; i++) {
    	var feature = e.features[i];
  	   
    var f = e.features[i],
        d = f.data,
        c = f.element,
        p = c.parentNode,
        pp = p.parentNode,
        u = f.element = po.svg("text");
      	name = d.properties.Nombre;

    
    u.setAttributeNS(null,"font-size","10px");
    u.setAttributeNS(null,"text-anchor","middle");
    //console.log(c.childNodes(0).getAttribute("transform"));
    u.setAttribute("transform", c.childNodes(0).getAttribute("transform"));
  
  
  
  
    var textNode = document.createTextNode(name);
    
    u.appendChild(textNode);
    
   p.removeChild(c);
   p.appendChild(u);
    


	  
	  }
  }

  //, cat, title, cantinas, tiendas, elec, alumnos, hogares, codigo, pob, data
function set_footer(i) {

///console.log(i);
	feature= commData.features[i];
	
	//console.log(feature);
	var properties = feature.data.properties;
	
	 var title = properties.NOMBRE;
      var codigo = properties.COMCODIGO;
      var pob = properties.POBLACION;
      var cat = properties.CATEGORIA;
      var hog = properties.HOGARES;
      var alumnos = properties.ALUMNOS;
      var elec	= properties.ELECTRICIA;
      var tiendas = properties.TIENDAS;
      var cantinas = properties.CANTINAS;
       var pres = properties.COCODE;
        var tel = properties.TEL;
      var area = (Math.round((properties.Shape_Ar_1 / 1000000)*100)/100);
      var perim = (Math.round((properties.Shape_Le_1 / 1000)*100)/100);
	
	
	var ft = document.getElementById('infobox_text');
	var html = '<comtitle>' + cat + ' ' + title + '</comtitle>'+ 
				'<h1>General</h1>' +
				'<ul><li>Codigo: ' + codigo + 
				'</li><li>Tiendas: ' + tiendas +
				//'</li><li>Cantinas: ' + cantinas +
				'</li><li>Hogares: ' + hog +
				'</li><li>Alumnos: ' + alumnos +
				'</li><li>Electricidad: ' + elec + 
				'%</li><li>Población: ' + pob + '</li></ul>' +
				'<h1>Datos Geografícos</h1>' +
				'<ul><li>Area: ' + area + ' km<sup>2</sup>' +
				'</li><li>Perímetro: ' + perim + ' km<sup>2</sup></li></ul>' +
			    '<h1>Presidente de COCODE</h1>' +
			    '<ul><li>' + pres +
			    '</li><li>Tel: ' + tel + '</li></ul>';


				
	ft.innerHTML = html;
}

function clear_footer(){
	var ft = document.getElementById('footer_text');
	ft.innerHTML = '&#160;';
}



/** A lightweight layer implementation for an image overlay. */
function overlay(tile, proj) {
  proj = proj(tile);
  var tl = proj.locationPoint({lon: -91.7835, lat: 15.6171}),
      br = proj.locationPoint({lon: -91.6919, lat: 15.5518}),
      image = tile.element = po.svg("image");
  image.setAttribute("preserveAspectRatio", "none");
  image.setAttribute("x", tl.x);
  image.setAttribute("y", tl.y);
  image.setAttribute("width", br.x - tl.x);
  image.setAttribute("height", br.y - tl.y);
  image.setAttributeNS("http://www.w3.org/1999/xlink", "href", "hill.png");
}

function overlay2(tile, proj) {
  proj = proj(tile);
  var tl = proj.locationPoint({lon: -91.7835, lat: 15.6171}),
      br = proj.locationPoint({lon: -91.6919, lat: 15.5518}),
      image = tile.element = po.svg("image");
  image.setAttribute("preserveAspectRatio", "none");
  image.setAttribute("x", tl.x);
  image.setAttribute("y", tl.y);
  image.setAttribute("width", br.x - tl.x);
  image.setAttribute("height", br.y - tl.y);
  image.setAttributeNS("http://www.w3.org/1999/xlink", "href", "names.png");
}





    
